#!/usr/bin/env python3
import os
import sys
import tty
import termios
import subprocess
import getpass
import shlex

# Define ANSI color codes
ORANGE = "\033[38;5;208m"
RED = "\033[31m"
BLUE = "\033[34m"
GRAY = "\033[90m"
RESET = "\033[0m"
CLEAR_LINE = "\r\033[2K"

print("Welcome to the Python Terminal Shell Environment.")
print("Type 'exit' to log out. Use Tab or Right-Arrow to complete commands.\n")

def get_all_commands():
    """Indexes available system binaries into memory on initialization."""
    commands = {'cd', 'exit', 'alias', 'export', 'echo', 'sysinfo', 'history'}
    paths = ['/bin', '/usr/bin', '/sbin', '/usr/sbin']
    for path in paths:
        if os.path.exists(path):
            try:
                for item in os.listdir(path):
                    commands.add(item)
            except PermissionError:
                continue
    return sorted(list(commands)), commands

# Cache lookups into memory to eliminate disk read latency
SYSTEM_COMMANDS_LIST, SYSTEM_COMMANDS_SET = get_all_commands()
HISTORY = []

def is_valid_command(cmd_string):
    """Performs instant hash lookups against the cached system command set."""
    # Fix 2: Clean up spaces properly via shlex to prevent empty command evaluations
    try:
        parts = shlex.split(cmd_string.strip())
    except ValueError:
        parts = cmd_string.strip().split(' ')
        
    if not parts or not parts[0]:
        return True
    return parts[0] in SYSTEM_COMMANDS_SET

def get_autocomplete_hint(buffer):
    """Retrieves inline command matches from the cached memory structure."""
    if not buffer or is_valid_command(buffer) or ' ' in buffer:
        return ""
    for cmd in SYSTEM_COMMANDS_LIST:
        if cmd.startswith(buffer):
            return cmd[len(buffer):]
    return ""

def get_closest_command(typo):
    """Calculates Levenshtein distance thresholds for input spell-checking."""
    def distance(s1, s2):
        if len(s1) < len(s2):
            return distance(s2, s1)
        if len(s2) == 0:
            return len(s1)
        prev = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            curr = [i + 1]
            for j, c2 in enumerate(s2):
                curr.append(min(prev[j+1]+1, curr[j]+1, prev[j]+(c1!=c2)))
            prev = curr
        return prev[-1]
    best_match, min_dist = None, 3
    for cmd in SYSTEM_COMMANDS_LIST:
        dist = distance(typo, cmd)
        if dist < min_dist:
            min_dist, best_match = dist, cmd
    return best_match

def print_sysinfo():
    """Displays core kernel memory statistics and configuration baselines."""
    print(f"\n{ORANGE}--- System Information Matrix ---{RESET}")
    try:
        with open('/proc/meminfo', 'r') as f:
            total, free = 0, 0
            for line in f:
                if "MemTotal" in line:
                    total = int(line.split()[1]) // 1024
                if "MemFree" in line:
                    free = int(line.split()[1]) // 1024
            print(f"Memory Allocation: {total - free} MB / {total} MB")
    except Exception:
        print("Memory Allocation: Unable to read system metrics")
    print(f"Active Account: {getpass.getuser()}")
    print(f"Execution Subshell: Python {sys.version.split()[0]}\n")

def print_history():
    """Displays the chronological shell execution history."""
    if not HISTORY:
        print("History log is empty.")
        return
    print()
    for idx, cmd in enumerate(HISTORY, start=1):
        print(f" {GRAY}{idx:>3}{RESET}  {cmd}")
    print()

def get_live_input(prompt_prefix):
    """Captures character buffers natively and renders real-time syntax coloring."""
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    buffer = ""
    history_index = len(HISTORY)
    
    try:
        tty.setraw(fd)
        sys.stdout.write(prompt_prefix)
        sys.stdout.flush()
        while True:
            char = sys.stdin.read(1)
            if char in ['\r', '\n']:
                sys.stdout.write('\r\n')
                sys.stdout.flush()
                break
            elif char == '\x7f':  # Backspace
                if len(buffer) > 0:
                    buffer = buffer[:-1]
            elif char == '\x1b':  # Escape sequence (Arrows)
                next1, next2 = sys.stdin.read(1), sys.stdin.read(1)
                if next1 == '[':
                    if next2 == 'A':  # Up Arrow
                        if history_index > 0:
                            history_index -= 1
                            buffer = HISTORY[history_index]
                    elif next2 == 'B':  # Down Arrow
                        if history_index < len(HISTORY) - 1:
                            history_index += 1
                            buffer = HISTORY[history_index]
                        else:
                            history_index = len(HISTORY)
                            buffer = ""
                    elif next2 == 'C':  # Right Arrow (Autocomplete)
                        hint = get_autocomplete_hint(buffer)
                        if hint:
                            buffer += hint
            elif char == '\t':  # Tab (Autocomplete)
                hint = get_autocomplete_hint(buffer)
                if hint:
                    buffer += hint
            elif char == '\x03':  # Ctrl+C
                raise KeyboardInterrupt
            elif 32 <= ord(char) <= 126:
                buffer += char

            # --- RENDER REFRESH ENGINE ---
            text_color = BLUE if is_valid_command(buffer) else RED
            hint = get_autocomplete_hint(buffer)
            
            sys.stdout.write(CLEAR_LINE)
            sys.stdout.write(f"{prompt_prefix}{text_color}{buffer}{GRAY}{hint}{RESET}")
            if hint:
                sys.stdout.write("\b" * len(hint))
            sys.stdout.flush()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return buffer

# Main Command Execution Loop
while True:
    try:
        current_dir = os.getcwd()
        home_path = os.path.expanduser("~")
        display_path = current_dir.replace(home_path, "~", 1) if current_dir.startswith(home_path) else current_dir
        prompt_prefix = f"{ORANGE}{display_path} >{RESET} "
        
        # Capture raw user text
        raw_command = get_live_input(prompt_prefix)
        command = raw_command.strip()
        
        # Fix 2: Safe evaluation logic for empty/whitespace inputs
        if not command:
            continue
            
        try:
            parts = shlex.split(command)
        except ValueError as e:
            print(f"shell: syntax error: {e}")
            continue
            
        if not parts:
            continue
            
        first_word = parts[0]
        
        if not HISTORY or HISTORY[-1] != command:
            HISTORY.append(command)
            
        if command == "exit":
            print("Terminating session layout...")
            break
            
        if command == "sysinfo":
            print_sysinfo()
            continue

        if command == "history":
            print_history()
            continue
            
        if not is_valid_command(command):
            suggestion = get_closest_command(first_word)
            if suggestion:
                print(f"Did you mean: {ORANGE}{suggestion}{RESET}?")
            else:
                print(f"shell: {first_word}: command not found")
            continue
            
        if command.startswith("cd "):
            target_dir = command[3:].strip()
            expanded_dir = os.path.expanduser(target_dir)
            try:
                os.chdir(expanded_dir)
            except Exception as e:
                print(f"shell: cd: {target_dir}: {e}")
            continue
            
        # Fix 1 & 3: Save terminal settings before handoff to sub-processes
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        
        try:
            # Drop raw mode so child tools (nano, vim, htop) get regular terminal controls
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            
            # Run application. shell=True allows Linux kernels to naturally manage rapid output buffers
            subprocess.run(command, shell=True, check=False)
        finally:
            # Guarantee that our shell re-acquires control safely when child tasks finish
            sys.stdout.flush()
    except (KeyboardInterrupt, EOFError):
        print(f"\nUse 'exit' to close the terminal session.")
