#!/bin/bash

# Define UI formatting colors
ORANGE='\033[38;5;208m'
GREEN='\033[32m'
RED='\033[31m'
RESET='\033[0m'

echo -e "${ORANGE}--- pytrm Terminal Shell Installer ---${RESET}"
echo "Target Environment: Ubuntu Base 26.04"
echo "---------------------------------------"

# 1. Enforce root execution privileges
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Error: Please run this installer with sudo privileges.${RESET}"
    echo "Usage: sudo ./pytrmInstaller.sh"
    exit 1
fi

# 2. Verify Python 3 presence on the core system
echo "Checking system dependency matrices..."
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}Error: Python3 is not installed on this system.${RESET}"
    echo "Installing Python3 core dependencies via apt..."
    apt update && apt install -y python3
else
    echo -e "${GREEN}✓ Python3 core environment detected.${RESET}"
fi

# 3. Pull raw code directly from your public GitHub Gist
echo "Downloading pytrm.py from your official GitHub Gist baseline..."
RAW_URL="https://gist.github.com/squiddy-coder-article/f7582f5e340817312ceba958f878ba98/raw/pytrm.py"
TARGET_BIN="/usr/local/bin/pytrm"

curl -sL "$RAW_URL" -o "$TARGET_BIN"

# 4. Check if the network file download succeeded
if [ $? -eq 0 ] && [ -s "$TARGET_BIN" ]; then
    echo -e "${GREEN}✓ Source package successfully deployed to $TARGET_BIN.${RESET}"
else
    echo -e "${RED}Error: Failed to download source binary. Verify your internet connectivity.${RESET}"
    exit 1
fi

# 5. Apply global executable permissions
echo "Configuring operational execution flags..."
chmod +x "$TARGET_BIN"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Permission flags set successfully.${RESET}"
else
    echo -e "${RED}Error: Failed to apply executable permissions.${RESET}"
    exit 1
fi

# 6. Final success confirmation layout
echo "---------------------------------------"
echo -e "${GREEN}Installation Complete! pytrm is now deployed globally.${RESET}"
echo -e "To launch your new shell environment, simply type: ${ORANGE}pytrm${RESET}"
echo "---------------------------------------"
